import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GetComponent } from './get/get.component';
import { WpService } from './wp.service';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    GetComponent,
    HomeComponent
  ],
  imports: [

  BrowserModule,
    AppRoutingModule,
HttpClientModule
  ],
  providers: [WpService],
  bootstrap: [AppComponent]
})
export class AppModule { }
