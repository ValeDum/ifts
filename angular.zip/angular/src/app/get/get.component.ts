import { Component, OnInit } from '@angular/core';
import { WpService } from './../wp.service';
import { Subscriber } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-get',
  templateUrl: './get.component.html',
  styleUrls: ['./get.component.css']
})
export class GetComponent implements OnInit {

  constructor(private wpService : WpService,
    private route: ActivatedRoute) { }

  singlePost: any;
  id!: string;
  wpPosts:any
  errorMessage:any

  ngOnInit() {
    this.getPosts();

    this.id = this.route.snapshot.paramMap.get('id') as string;
    console.log(this.id);
    this.getSinglePost();
  }

  getPosts() {

this.wpService.getPosts().subscribe((data) => {
  this.wpPosts = data
  console.log(data);
},
(error) => {
  this.errorMessage = error.error.message;
  console.log(error.error.message, 'error');
}
);

    }


    getSinglePost() {

      this.wpService.getSinglePost(this.id).subscribe(
        (data) => {
          this.singlePost = data;
          console.log(this.singlePost);
        },
        (error) => {
          this.errorMessage = error.error.message;
          console.log(error.error.message, 'error');

        }
      );

 }

  }


