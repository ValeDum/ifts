<?php
/**
 * Il file base di configurazione di WordPress.
 *
 * Questo file viene utilizzato, durante l’installazione, dallo script
 * di creazione di wp-config.php. Non è necessario utilizzarlo solo via web
 * puoi copiare questo file in «wp-config.php» e riempire i valori corretti.
 *
 * Questo file definisce le seguenti configurazioni:
 *
 * * Impostazioni database
 * * Chiavi Segrete
 * * Prefisso Tabella
 * * ABSPATH
 *
 * * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Impostazioni database - È possibile ottenere queste informazioni dal proprio fornitore di hosting ** //
/** Il nome del database di WordPress */
define('DB_NAME', 'wordpress');

/** Nome utente del database */
define('DB_USER', 'userdb1');

/** Password del database */
define('DB_PASSWORD', 'StaMinchia1');

/** Hostname del database */
define('DB_HOST', 'localhost');

/** Charset del Database da utilizzare nella creazione delle tabelle. */
define('DB_CHARSET', 'utf8');

/** Il tipo di Collazione del Database. Da non modificare se non si ha idea di cosa sia. */
define('DB_COLLATE', '');

/**#@+
 * Chiavi Univoche di Autenticazione e di Salatura.
 *
 * Modificarle con frasi univoche differenti!
 * È possibile generare tali chiavi utilizzando {@link https://api.wordpress.org/secret-key/1.1/salt/ servizio di chiavi-segrete di WordPress.org}
 * È possibile cambiare queste chiavi in qualsiasi momento, per invalidare tuttii cookie esistenti. Ciò forzerà tutti gli utenti ad effettuare nuovamente il login.
 *
 * @since 2.6.0
 */
// define('AUTH_KEY',         'Mettere la vostra frase unica qui');
// define('SECURE_AUTH_KEY',  'Mettere la vostra frase unica qui');
// define('LOGGED_IN_KEY',    'Mettere la vostra frase unica qui');
// define('NONCE_KEY',        'Mettere la vostra frase unica qui');
// define('AUTH_SALT',        'Mettere la vostra frase unica qui');
// define('SECURE_AUTH_SALT', 'Mettere la vostra frase unica qui');
// define('LOGGED_IN_SALT',   'Mettere la vostra frase unica qui');
// define('NONCE_SALT',       'Mettere la vostra frase unica qui');

define('AUTH_KEY',         '}Z-zwzT)|r`/80L&xG=z-`=H@s:dVnK,Z[73pq/RvoJ$|Z$xZ|qy@|JO:GL{FE/:');
	define('SECURE_AUTH_KEY',  'IA~}NP9E98V.m4<*;%+2rw3:QBY<aAt#V@La7wWoOhm&W-y>|K@aEB!6pcNB]N+:');
	define('LOGGED_IN_KEY',    'abcaZN@*Yud8U|nE{F6y7#GBc4]i1Q|{UjA?n)%1E4t=nG+_n#;c*^a.L{W303M<');
	define('NONCE_KEY',        'h9-3dQrv,A9Wc-tZ@T}uU|t[/VtOZ/T`j:K{ylB>tBc03,|1+-!ie5^@<mB90.Bf');
	define('AUTH_SALT',        'Ji]lX2+TQw/18#MA4;j[ApW?DQa8cG[+{HyW`7H@`O`YO_8%R6/7xu~FumFcb6Gv');
	define('SECURE_AUTH_SALT', '|!*|vLkpx|</7I&FQOt;qV.DJK}4w,o=l+EtPca$I@{,RB);T=%j$aCn/eCK5^t,');
	define('LOGGED_IN_SALT',   '#RiGv;1O+QsY(MTC:UYm*>?&(+>1j?ySl~b/(9Sa]?pKDnw/%(X|u+sf>M+(Z]Ho');
	define('NONCE_SALT',       '<iWD?{|*upMYj=_)gHW6?HK-8*zGy,[n2[*@udK=J]mY-!B(sDJSrlX--z@30+d<');
/**#@-*/

/**
 * Prefisso Tabella del Database WordPress.
 *
 * È possibile avere installazioni multiple su di un unico database
 * fornendo a ciascuna installazione un prefisso univoco.
 * Solo numeri, lettere e sottolineatura!
 */
$table_prefix = 'wp_';

/**
 * Per gli sviluppatori: modalità di debug di WordPress.
 *
 * Modificare questa voce a TRUE per abilitare la visualizzazione degli avvisi durante lo sviluppo
 * È fortemente raccomandato agli svilupaptori di temi e plugin di utilizare
 * WP_DEBUG all’interno dei loro ambienti di sviluppo.
 *
 * Per informazioni sulle altre costanti che possono essere utilizzate per il debug,
 * leggi la documentazione
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define('WP_DEBUG', false);

/* Finito, interrompere le modifiche! Buon blogging. */

/** Path assoluto alla directory di WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Imposta le variabili di WordPress ed include i file. */
require_once(ABSPATH . 'wp-settings.php');
